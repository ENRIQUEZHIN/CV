document.addEventListener('DOMContentLoaded', function() {
    videojs('myVideo1');
  });
